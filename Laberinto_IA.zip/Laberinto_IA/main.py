import heapq
import pygame

# 0 = camino; 1 = pared. El mapa debe tener ancho/alto impares para este diseño.
MAZE = [
    "1111111111111111111",
    "1000001000000000001",
    "1011101011110111101",
    "1010001000010100001",
    "1010111111010101101",
    "1010000000010000101",
    "1011110111111100101",
    "1000010000000000101",
    "1111011110111110101",
    "1000000010000010001",
    "1011111010111011101",
    "1000000010000000001",
    "1111111111111111111",
]
TILE = 40
HUD = 82
ROWS, COLS = len(MAZE), len(MAZE[0])
WIDTH, HEIGHT = COLS * TILE, ROWS * TILE + HUD
FPS = 60

BG = (18, 22, 34)
WALL = (49, 61, 85)
FLOOR = (235, 239, 245)
GRID = (211, 218, 230)
PLAYER_COLOR = (40, 120, 255)
ROBOT_COLOR = (238, 73, 84)
GOAL_COLOR = (45, 180, 110)
PATH_COLOR = (255, 205, 65)
VISITED_COLOR = (120, 190, 255)
TEXT = (245, 247, 252)


def cell_center(cell):
    r, c = cell
    return c * TILE + TILE // 2, HUD + r * TILE + TILE // 2


def walkable(cell):
    r, c = cell
    return 0 <= r < ROWS and 0 <= c < COLS and MAZE[r][c] == "0"


def neighbors(cell):
    r, c = cell
    for nxt in ((r - 1, c), (r, c + 1), (r + 1, c), (r, c - 1)):
        if walkable(nxt):
            yield nxt


def dijkstra(start, goal):
    """Devuelve (ruta, explorados). Encuentra ruta de costo mínimo."""
    frontier = [(0, start)]
    came_from = {start: None}
    cost = {start: 0}
    explored = []
    while frontier:
        current_cost, current = heapq.heappop(frontier)
        if current_cost != cost.get(current):
            continue
        explored.append(current)
        if current == goal:
            break
        for nxt in neighbors(current):
            new_cost = current_cost + 1
            if new_cost < cost.get(nxt, float("inf")):
                cost[nxt] = new_cost
                came_from[nxt] = current
                heapq.heappush(frontier, (new_cost, nxt))
    return reconstruct(came_from, start, goal), explored


def heuristic(a, b):
    # Distancia Manhattan: adecuada para movimiento en cuatro direcciones.
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def astar(start, goal):
    """Devuelve (ruta, explorados). A* combina costo real y heurística."""
    frontier = [(heuristic(start, goal), 0, start)]
    came_from = {start: None}
    cost = {start: 0}
    explored = []
    while frontier:
        _, current_cost, current = heapq.heappop(frontier)
        if current_cost != cost.get(current):
            continue
        explored.append(current)
        if current == goal:
            break
        for nxt in neighbors(current):
            new_cost = cost[current] + 1
            if new_cost < cost.get(nxt, float("inf")):
                cost[nxt] = new_cost
                came_from[nxt] = current
                heapq.heappush(frontier, (new_cost + heuristic(nxt, goal), new_cost, nxt))
    return reconstruct(came_from, start, goal), explored


def reconstruct(came_from, start, goal):
    if goal not in came_from:
        return [], []
    path = []
    current = goal
    while current is not None:
        path.append(current)
        current = came_from[current]
    path.reverse()
    return path, []


class MazeGame:
    def __init__(self):
        pygame.init()
        pygame.display.set_caption("Laberinto IA — A* y Dijkstra")
        self.screen = pygame.display.set_mode((WIDTH, HEIGHT))
        self.clock = pygame.time.Clock()
        self.font = pygame.font.SysFont("arial", 20)
        self.small = pygame.font.SysFont("arial", 16)
        self.reset()

    def reset(self):
        self.player = (1, 1)
        self.robot = (11, 17)
        self.goal = (1, 17)
        self.algorithm = "A*"
        self.path = []
        self.explored = []
        self.explored_count = 0
        self.won = False
        self.caught = False
        self.replan()

    def replan(self):
        search = astar if self.algorithm == "A*" else dijkstra
        self.path, self.explored = search(self.robot, self.player)
        self.explored_count = len(self.explored)

    def move_player(self, dr, dc):
        if self.won or self.caught:
            return
        nxt = (self.player[0] + dr, self.player[1] + dc)
        if walkable(nxt):
            self.player = nxt
            if self.player == self.goal:
                self.won = True
            if self.player == self.robot:
                self.caught = True
            self.replan()

    def move_robot(self):
        if self.won or self.caught or not self.path:
            return
        # Recalcula el camino a la posición actual del jugador y avanza un paso.
        self.replan()
        if len(self.path) > 1:
            self.robot = self.path[1]
        if self.robot == self.player:
            self.caught = True

    def draw(self):
        self.screen.fill(BG)
        title = self.font.render("LABERINTO IA  |  1: Dijkstra   2: A*   R: reiniciar", True, TEXT)
        self.screen.blit(title, (12, 10))
        subtitle = self.small.render(
            f"Algoritmo: {self.algorithm} | Celdas exploradas en último cálculo: {self.explored_count} "
            "| Flechas/WASD: mover | Robot: persigue al jugador",
            True, TEXT)
        self.screen.blit(subtitle, (12, 43))

        # Celdas visitadas (azul claro) y ruta calculada (amarillo).
        for r, c in self.explored:
            pygame.draw.rect(self.screen, VISITED_COLOR,
                             (c * TILE + 4, HUD + r * TILE + 4, TILE - 8, TILE - 8), border_radius=5)
        for r, c in self.path:
            pygame.draw.rect(self.screen, PATH_COLOR,
                             (c * TILE + 8, HUD + r * TILE + 8, TILE - 16, TILE - 16), border_radius=5)

        for r, row in enumerate(MAZE):
            for c, value in enumerate(row):
                rect = pygame.Rect(c * TILE, HUD + r * TILE, TILE, TILE)
                if value == "1":
                    pygame.draw.rect(self.screen, WALL, rect)
                else:
                    pygame.draw.rect(self.screen, FLOOR, rect)
                    pygame.draw.rect(self.screen, GRID, rect, 1)

        # Volver a dibujar ruta encima del suelo para que quede visible.
        for r, c in self.path:
            pygame.draw.rect(self.screen, PATH_COLOR,
                             (c * TILE + 13, HUD + r * TILE + 13, TILE - 26, TILE - 26), border_radius=4)

        gx, gy = cell_center(self.goal)
        pygame.draw.circle(self.screen, GOAL_COLOR, (gx, gy), TILE // 3)
        px, py = cell_center(self.player)
        pygame.draw.circle(self.screen, PLAYER_COLOR, (px, py), TILE // 3)
        rx, ry = cell_center(self.robot)
        pygame.draw.circle(self.screen, ROBOT_COLOR, (rx, ry), TILE // 3)

        legend = self.small.render("Azul: jugador   Rojo: robot   Verde: salida   Amarillo: ruta   Azul claro: exploración",
                                   True, TEXT)
        self.screen.blit(legend, (12, HEIGHT - 24))
        if self.won or self.caught:
            message = "¡Ganaste! Llegaste a la salida." if self.won else "¡El robot te alcanzó! Pulsa R para volver a jugar."
            overlay = pygame.Surface((WIDTH, 42), pygame.SRCALPHA)
            overlay.fill((15, 20, 30, 220))
            self.screen.blit(overlay, (0, HEIGHT // 2 - 21))
            msg = self.font.render(message, True, TEXT)
            self.screen.blit(msg, (WIDTH // 2 - msg.get_width() // 2, HEIGHT // 2 - 12))
        pygame.display.flip()

    def run(self):
        running = True
        robot_timer = 0
        while running:
            dt = self.clock.tick(FPS)
            robot_timer += dt
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_ESCAPE:
                        running = False
                    elif event.key == pygame.K_r:
                        self.reset()
                    elif event.key == pygame.K_1:
                        self.algorithm = "Dijkstra"
                        self.replan()
                    elif event.key == pygame.K_2:
                        self.algorithm = "A*"
                        self.replan()
                    elif event.key in (pygame.K_UP, pygame.K_w):
                        self.move_player(-1, 0)
                    elif event.key in (pygame.K_DOWN, pygame.K_s):
                        self.move_player(1, 0)
                    elif event.key in (pygame.K_LEFT, pygame.K_a):
                        self.move_player(0, -1)
                    elif event.key in (pygame.K_RIGHT, pygame.K_d):
                        self.move_player(0, 1)

            if robot_timer >= 550:
                robot_timer = 0
                self.move_robot()
            self.draw()
        pygame.quit()


if __name__ == "__main__":
    MazeGame().run()
