# Laberinto IA — proyecto base

Videojuego 2D en Python + Pygame con un jugador, un robot perseguidor y comparación de rutas mediante Dijkstra y A*.

## Requisitos
- Python 3.10 o posterior
- Pygame

## Instalar
Abre una terminal en esta carpeta y ejecuta:

```bash
python -m pip install -r requirements.txt
```

En Windows, si `python` no funciona, prueba `py -m pip install -r requirements.txt`.

## Ejecutar
```bash
python main.py
```

## Controles
- Flechas o WASD: mover al jugador
- R: reiniciar
- 1: usar Dijkstra para que el robot calcule la ruta
- 2: usar A* para que el robot calcule la ruta
- ESC: salir

## Qué implementa
- Laberinto representado como una cuadrícula (0 = camino, 1 = pared)
- Movimiento del jugador con colisiones
- Robot que recalcula su ruta hacia el jugador
- Dijkstra: búsqueda de camino de costo mínimo en una cuadrícula sin pesos
- A*: búsqueda informada usando distancia Manhattan como heurística
- Visualización de celdas exploradas y ruta encontrada
- Comparación básica del número de celdas exploradas

## Nota sobre IA
Es una IA basada en búsqueda y toma de decisiones: el robot observa la posición del jugador y calcula una ruta. No es aprendizaje automático; no entrena con ejemplos. Si la consigna exige machine learning, se debe añadir un componente entrenado por separado.
